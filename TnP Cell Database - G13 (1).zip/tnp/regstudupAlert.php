<div class="alert alert-success" role="alert">
  Data Updated !!!! Go Back!!!
</div>